=== EthereumAds - Earn Cryptocurrency with Banner Ads ===
Contributors: ethereumads
Tags: banner, ads, ethereum, bitcoin, advertising, banner advertising, cryptocurrency
Requires at least: 2.8
Tested up to: 6.0.0
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Instantly monetize your content by simply setting your Ethereum address. Multiple banner sizes available. No signup needed.

== Description ==

Earn cryptocurrency with banner ads. Monetize your content in under 1 minute by simply adding our widget to your WordPress site.
 
After you inserted our widget your ad space is automatically openly auctioned off using our smart contract to the highest bidder. Just let our open bidding market automatically and continually find the perfect ads for you. Your earnings go directly into your Ethereum wallet.

Ethereum (ETH) is the second largest crypto currency after Bitcoin (BTC). EthereumAds enables trustless and privacy preserving banner advertising. 

For more information visit [https://ethereumads.com/](https://ethereumads.com/)

== Installation ==

Once the zip file has been downloaded to your local computer:

1. From Plugins, click Add New, then Upload, select the previously downloaded zip file and click Install Now

2. Click the 'Activate' link for EthereumAds Widget on your Plugins page.

3. Check the 'Settings" link and paste in your Ethereum public key and choose a banner size.

4. Go to Appearance, Widgets and drag and drop the widget to wherever you want to show it on the Sidebar.

You can see how it all works on [https://ethereumads.com/](https://ethereumads.com/)

