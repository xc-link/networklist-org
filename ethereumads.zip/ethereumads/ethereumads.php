<?php
/*
Plugin Name: EthereumAds
Plugin URI: https://ethereumads.com/ethereumads.zip
Description: Earn cryptocurrency with banner ads. Monetize your content in under 1 minute by simply adding our widget to your Wordpress site. Just insert your Ethereum address and select a banner size in the plugin settings and get paid in Ether automatically. No signup needed.
Version: 1.0.1
Author: EthereumAds Team
Author URI: https://ethereumads.com
*/

/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

/**
 * Widget
 */
if ( ! class_exists( 'Ethereumads_Widget' ) ) {

	class Ethereumads_Widget extends WP_Widget {

		/** constructor */
		function __construct() {
			parent::__construct( false, $name = 'EthereumAds', array( "description" => "Displays links from the EthereumAds Network" ) );
		}

		/** @see WP_Widget::update */
		function update( $new_instance, $old_instance ) {
			return $new_instance;
		}

		/** @see WP_Widget::form */
		function form( $instance ) {
			$title = esc_attr( isset($instance['title']) ? $instance['title'] : '');
			?>
			<p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title: (optional)' ); ?>
					<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" /></label>
			</p>
			<?php
		}

		/**
		 * Output the content of the widget
		 *
		 * @param <type> $args
		 * @param <type> $instance
		 */
		function widget( $args, $instance ) {
			extract( $args );
			?>
			<?php echo $before_widget; ?>
			<?php echo $before_title . $instance['title'] . $after_title; ?>
			<?php
			//Call EthereumAds custom code
			init_ethereumads();
			?>
			<?php echo $after_widget; ?>
			<?php
		}

	} // class Ethereumads_Widget
}

// register Ethereumads_Widget widget
add_action( 'widgets_init', function() { return register_widget("Ethereumads_Widget"); } );

add_shortcode('ethereumads','ethereumads_widget');

function ethereumads_widget() {

    global $wp_widget_factory;

    $atts['widget_name'] = 'Ethereumads_Widget';

    extract(shortcode_atts(array(
        'widget_name' => FALSE
    ), $atts));

    $widget_name = wp_specialchars($widget_name);

    if (!is_a($wp_widget_factory->widgets[$widget_name], 'WP_Widget')):
        $wp_class = 'WP_Widget_'.ucwords(strtolower($class));

        if (!is_a($wp_widget_factory->widgets[$wp_class], 'WP_Widget')):
            return '<p>'.sprintf(__("%s: Widget class not found. Make sure this widget exists and the class name is correct"),'<strong>'.$class.'</strong>').'</p>';
        else:
            $class = $wp_class;
        endif;
    endif;

    ob_start();
    the_widget($widget_name, $instance, array('widget_id'=>'arbitrary-instance-'.$id,
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '',
        'after_title' => ''
    ));
    $output = ob_get_contents();
    ob_end_clean();
    return $output;
}

/**
 * Settings page
 */

//Init settings
add_action( 'admin_init', 'ethereumads_settings_init' );
function ethereumads_settings_init() {

	//Register setting sections and fields
	//All settings are saved in one array called ethereumads_options
	register_setting( 'ethereumads-settings-group', 'ethereumads_options' );
	add_settings_section( 'ethereumads-settings-section-general', 'General Settings', 'ethereumads_settings_section_general', 'ethereumads-settings-page' );
	add_settings_field( 'ethereumads-settings-field-account_code', 'Ethereum address', 'ethereumads_settings_field_account_code', 'ethereumads-settings-page', 'ethereumads-settings-section-general' );
	add_settings_field( 'ethereumads-settings-field-banner_size', 'Banner size', 'ethereumads_settings_field_banner_size', 'ethereumads-settings-page', 'ethereumads-settings-section-general' );
	
	//add_settings_field( 'ethereumads-settings-field-slot', 'Slot', 'ethereumads_settings_field_slot', 'ethereumads-settings-page', 'ethereumads-settings-section-general' );
	//add_settings_field( 'ethereumads-settings-field-cache_folder', 'Cache Folder', 'ethereumads_settings_field_cache_folder', 'ethereumads-settings-page', 'ethereumads-settings-section-cache' );
	//add_settings_field( 'ethereumads-settings-field-cache_time', 'Cache time (hours)', 'ethereumads_settings_field_cache_time', 'ethereumads-settings-page', 'ethereumads-settings-section-cache' );
	//add_settings_section( 'ethereumads-settings-section-cache', 'Cache Settings', 'ethereumads_settings_section_cache', 'ethereumads-settings-page' );


	//Set defaults
	$account_code = '';
	if ( strlen( $account_code ) == 11 ) {
		$account_code = '';
	}
	$options = get_option( 'ethereumads_options' );
	if ( empty( $options['account_code'] ) ) {
		$options['account_code'] = $account_code;
	}
	if ( empty( $options['cache_folder'] ) ) {
		$options['cache_folder'] = 'ethereumads_cache';
	}
	if ( empty( $options['cache_time'] ) ) {
		$options['cache_time'] = '24';
	}
	if ( empty( $options['banner_size'] ) ) {
		$options['banner_size'] = '300x600';
	}
	if ( empty( $options['slot'] ) ) {
		$options['slot'] = '0';
	}
	update_option( 'ethereumads_options', $options );

}

//Show notice until the user enters their account code
add_action( 'admin_notices', 'ethereumads_warning' );
function ethereumads_warning() {

	$options = get_option( 'ethereumads_options' );
	if ( empty( $options['account_code'] ) ) {
		echo "<div id='ethereumads-warning' class='updated fade'><p><strong>EthereumAds is almost ready</strong>. Please <a href='options-general.php?page=ethereumads-settings-page'>enter your Ethereum address</a> to complete the installation.</strong></p></div>";
	}

}

//Register the method that holds the code for our settings link
add_action( 'admin_menu', 'ethereumads_plugin_menu' );

//Adds the settings page to the plugin menu 
function ethereumads_plugin_menu() {
	add_options_page( 'Settings', 'EthereumAds', 'manage_options', 'ethereumads-settings-page', 'ethereumads_settings' );
}

//Code for settings page
function ethereumads_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}
	?>
	<div class="wrap">
		<?php screen_icon(); ?>
		<h2>EthereumAds Settings</h2>

		<form method="post" action="options.php">
			<?php settings_fields( 'ethereumads-settings-group' ); ?>
			<?php do_settings_sections( 'ethereumads-settings-page' ); ?>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

//Section intros
function ethereumads_settings_section_cache() {
	echo "Do not change the default caching settings unless you know what you are doing";
}

function ethereumads_settings_section_general() {
	echo "If you have no Ethereum address you can just generate one with <a href='https://metamask.io' target='_blank' rel='nofollow'>Metamask</a><br><p>Remember that you can use the shortcode to show the banners where you like using: <code>[ethereumads]</code></p>";
}

//Fields: account_code
function ethereumads_settings_field_account_code() {
	$options = get_option( 'ethereumads_options' );
	echo "<input id='ethereumads-settings-field-account_code' name='ethereumads_options[account_code]' size='42' type='text' value='{$options['account_code']}' />";
}

//Fields: slot
function ethereumads_settings_field_slot() {
	$options = get_option( 'ethereumads_options' );
	echo "<input id='ethereumads-settings-field-slot' name='ethereumads_options[slot]' size='5' type='number' value='{$options['slot']}' />";
}


//Fields: cache_folder
function ethereumads_settings_field_cache_folder() {
	$options = get_option( 'ethereumads_options' );
	echo "<input id='ethereumads-settings-field-cache_folder' name='ethereumads_options[cache_folder]' size='80' type='text' value='{$options['cache_folder']}' />";
}

//Fields: cache_time
function ethereumads_settings_field_cache_time() {
	$options = get_option( 'ethereumads_options' );
	?>
	<select id='ethereumads-settings-field-cache_time' name='ethereumads_options[cache_time]'>
		<option value="24" <?php echo ( $options['cache_time'] == '24' ) ? 'selected="selected"' : ''; ?>>24 hours</option>
		<option value="48" <?php echo ( $options['cache_time'] == '48' ) ? 'selected="selected"' : ''; ?>>48 hours (2 days)</option>
		<option value="96" <?php echo ( $options['cache_time'] == '96' ) ? 'selected="selected"' : ''; ?>>96 hours (4 days)</option>
		<option value="168" <?php echo ( $options['cache_time'] == '168' ) ? 'selected="selected"' : ''; ?>>168 hours (One week)</option>
	</select>
	<?php
	//echo "<input id='ethereumads-settings-field-cache_time' name='ethereumads_options[cache_time]' size='40' type='text' value='{$options['cache_time']}' />";
}

//Fields: banner_size
function ethereumads_settings_field_banner_size() {
	$options = get_option( 'ethereumads_options' );
	?>
	<select id='ethereumads-settings-field-banner_size' name='ethereumads_options[banner_size]'>
		<option value="300x600" <?php echo ( $options['banner_size'] == '300x600' ) ? 'selected="selected"' : ''; ?>>300x600  Large skyscraper</option>
		<option value="336x280" <?php echo ( $options['banner_size'] == '336x280' ) ? 'selected="selected"' : ''; ?>>336x280 - Large rectangle</option>
		<option value="300x250" <?php echo ( $options['banner_size'] == '300x250' ) ? 'selected="selected"' : ''; ?>>300x250 - Medium rectangle</option>
		<option value="728x90" <?php echo ( $options['banner_size'] == '728x90' ) ? 'selected="selected"' : ''; ?>>728x90 - Leaderboard</option>
		<option value="320x50" <?php echo ( $options['banner_size'] == '320x50' ) ? 'selected="selected"' : ''; ?>>320x50 - Mobile leaderboard</option>
	</select>
	<?php
}

// Add settings link on plugin page
function ethereumads_settings_link( $links ) {
	$settings_link = '<a href="options-general.php?page=ethereumads-settings-page">Settings</a>';
	$links[]       = $settings_link;

	return $links;
}

$ethereumadsPlugin = plugin_basename( __FILE__ );
add_filter( "plugin_action_links_$ethereumadsPlugin", 'ethereumads_settings_link' );

/**
 * Clear Wordpress caches when clearing AB cache manually
 */
if ( ! empty( $_GET['ab_cc'] ) ) {

	//Clearing super cache if it exists
	if ( ! empty( $GLOBALS["super_cache_enabled"] ) ) {
		wp_cache_clear_cache();
	}

}

/**
 * EthereumAds Main function that calls all other ABC functions
 */
function init_ethereumads() {

	//Settings
	$options           = get_option( 'ethereumads_options' );
	$abCacheFolderName = $options['cache_folder'];
	$abAccountCode     = $options['account_code'];
	$abCacheHours      = $options['cache_time'];
	$bannerSize        = $options['banner_size'];
	$slot              = $options['slot'];

	if ( empty( $abAccountCode ) ) {
		echo "Please enter your EthereumAds account code in the plugin settings page";

		return false;
	}

	/**
	 * Do not change anything below
	 * Do not change anything below
	 * Do not change anything below
	 * Do not change anything below
	 * Do not change anything below
	 */

	$v     = "1.0";
	$s     = "wp28";
	$abMsg = array();
	$debug = false;
	if ( trim( @$_GET['ab_debug'] ) == $abAccountCode ) {
		$debug = true;
		echo "<li />Version: " . $v;
		echo "<li />System: " . $s;
		unset( $_GET['ab_debug'] );
	}

	//Show phpinfo if debug is on and phpinfo is requested
	if ( $debug && $_GET['phpinfo'] ) {

		?>
		<style type="text/css">
			#phpinfo_div {
				position   : fixed;
				bottom     : 0;
				left       : 0;
				height     : 300px;
				width      : 100%;
				overflow   : scroll;
				background : #F0F0F0;
				color      : #000;
				border-top : 2px solid;
				z-index    : 999;
			}
		</style>
		<div id="phpinfo_div">
			<?php echo phpinfo(); ?>
		</div>
		<?php

	}

	//Create cache folder if it does not exist
	$cacheFolder = ethereumadsGetCacheFolder( $abCacheFolderName, $debug );
	if ( $cacheFolder ) {

		//Current URL
		$page = ethereumadsGetPageUrl( $debug );
		if ( ethereumadsIsValidUrl( $page, $debug ) ) {

			$cacheFileName = $cacheFolder . "/" . ethereumadsGetCacheFileName( $page.$abAccountCode.$bannerSize.$slot, $debug );
			$cacheContent  = ethereumadsGetCache( $cacheFileName, $abCacheHours, $abCacheFolderName, $debug );
			if ( $cacheContent === false ) {
				//Get links from EthereumAds
				$freshContent = ethereumadsGetLinks( $page, $abAccountCode, $bannerSize, $slot, $debug );
				if ( $freshContent !== false ) {
					if ( ethereumadsSaveCache( $freshContent, $cacheFileName, $debug ) ) {
						$cacheContent = ethereumadsGetCache( $cacheFileName, $abCacheHours, $abCacheFolderName, $debug );
						if ( $cacheContent !== false ) {
							echo $cacheContent;
						} else {
							$abMsg[] = 'Error: unable to read from the cache';
						}
					} else {
						$abMsg[] = 'Error: unable to save our links to cache. Please make sure that the folder ' . $abCacheFolderName . ' located in the folder ' . $_SERVER['DOCUMENT_ROOT'] . ' and is writable';
					}
				} else {
					$abMsg[] = 'Error: unable to get links from server.';
				}
			} else {
				//Display the cached content
				echo $cacheContent;
			}

		} else {
			$abMsg[] = 'Error: your site reports that it is located on the following URL: ' . $page . ' - This is not a valid URL and we can not display links on this page. This is probably due to an incorrect setting of the $_SERVER variable.';
		}

	} else {
		$abMsg[] = 'Error: Unable to create or read from your link cache folder. Please try to create a folder by the name "' . $abCacheFolderName . '" directly in the root of your site and make it writable';
	}

	foreach ( $abMsg as $error ) {
		echo $error . "<br />";
	}

}

/**
 * EthereumAds Helper functions
 */

function ethereumadsSaveCache( $content, $file, $debug = false ) {

	//Prepend a timestamp to the content
	$content = time() . "|" . $content;

	echo ( $debug ) ? "<li />Saving Cache: " . $content : "";

	$fh = fopen( $file, 'w' );
	if ( $fh !== false ) {
		if ( ! fwrite( $fh, $content ) ) {
			echo ( $debug ) ? "<li />Error Saving Cache!" : "";

			return false;
		}
	} else {
		echo ( $debug ) ? "<li />Error opening cache file for writing!" : "";

		return false;
	}
	if ( ! fclose( $fh ) ) {
		echo ( $debug ) ? "<li />Error closing file handle!" : "";

		return false;
	}

	if ( ! file_exists( $file ) ) {
		echo ( $debug ) ? "<li />Error could not create cache file!" : "";

		return false;
	} else {
		echo ( $debug ) ? "<li />Cache file created successfully" : "";

		return true;
	}

}

//Deletes any cache file that is from before Today (Max 500)
function ethereumadsClearOldCache($cacheFolderName, $cacheHours, $debug=false) {

    $today = date('Ymd');
    $cacheFolder = ethereumadsGetCacheFolder($cacheFolderName);

    if (is_dir($cacheFolder)) {

        $allCacheFiles = glob($cacheFolder.'/*.cache');
        $todaysCacheFiles = glob($cacheFolder.'/'.$today.'*.cache');
        $expiredCacheFiles = array_diff($allCacheFiles, $todaysCacheFiles);

        $i = 0;
        foreach ($expiredCacheFiles as $expiredCacheFile) {
            echo ($debug) ? "<li />Deleting expired cache file: ".$expiredCacheFile : "";
            ethereumadsRemoveCacheFile($expiredCacheFile, $debug);

            // Limit to max 500
            $i++;
            if ($i >= 500) {
                break;
            }
        }
    }
}


//Returns the full path to the cache folder and also creates it if it does not work
function ethereumadsGetCacheFolder( $cacheFolderName, $debug = false ) {

	if ( isset( $_SERVER['DOCUMENT_ROOT'] ) ) {
		$docRoot = rtrim( $_SERVER['DOCUMENT_ROOT'], "/" ); //Remove any trailing slashes
	} else if ( isset( $_SERVER['PATH_TRANSLATED'] ) ) {
		$docRoot = rtrim( substr( $_SERVER['PATH_TRANSLATED'], 0, 0 - strlen( $_SERVER['PHP_SELF'] ) ), '\\' );
		$docRoot = str_replace( '\\\\', '/', $docRoot );
	} else {
		echo ( $debug ) ? "<li />Error: Could not construct cache path" : "";
	}
	$cacheFolder = $docRoot . "/" . $cacheFolderName;

	echo ( $debug ) ? "<li />Cache folder is: " . $cacheFolder : "";

	if ( ! file_exists( $cacheFolder ) ) {
		echo ( $debug ) ? "<li />Cache folder does not exist: " . $cacheFolder : "";
		if ( ! @mkdir( $cacheFolder, 0777 ) ) {
			echo ( $debug ) ? "<li />Error - could not create cache folder: " . $cacheFolder : "";

			return false;
		} else {
			echo ( $debug ) ? "<li />Successfully created cache folder" : "";
			//Also make an empty default html file
			$blankFile = $cacheFolder . "/index.html";
			if ( ! file_exists( $blankFile ) ) {
				$newFile = @fopen( $blankFile, "w" );
				@fclose( $newFile );
			}
		}
	}

	return $cacheFolder;

}

//Url validation
function ethereumadsIsValidUrl( $url, $debug = false ) {

	$urlBits = @parse_url( $url );
	if ( $urlBits['scheme'] != "http" && $urlBits['scheme'] != "https" ) {
		echo ( $debug ) ? "<li />Error! URL does not start with http: " . $url : "";

		return false;
	} else if ( strlen( $urlBits['host'] ) < 4 || strpos( $urlBits['host'], "." ) === false ) {
		echo ( $debug ) ? "<li />Error! URL is incorrect: " . $url : "";

		return false;
	}

	return true;
}

//Get the name of the cache file name
function ethereumadsGetCacheFileName( $url, $debug = false ) {

	$cacheFileName = date('Ymd').md5( $url ) . ".cache";
	echo ( $debug ) ? "<li />Cache file name for URL: " . $url . " is " . $cacheFileName : "";

	return $cacheFileName;

}

//Attempts to load the cache file
function ethereumadsGetCache( $cacheFile, $cacheHours, $cacheFolderName, $debug = false ) {

	//If the url is called with ab_cc=1 then discard the cache file
	if ( isset( $_GET['ab_cc'] ) && $_GET['ab_cc'] == "1" ) {
		echo ( $debug ) ? "<li />Clear cache invoked!" : "";
		ethereumadsRemoveCacheFile( $cacheFile );
		unset( $_GET['ab_cc'] );

		return false;
	}

	if ( ! file_exists( $cacheFile ) ) {
		echo ( $debug ) ? "<li />Error! Cache file does not exist! " . $cacheFile : "";

		return false;
	}

	$cache_contents = @file_get_contents( $cacheFile );

	if ( $cache_contents === false ) {
		echo ( $debug ) ? "<li />Error: Cache file is completely empty!" : "";

		return false;
	} else {
		echo ( $debug ) ? "<li />Cache file contents" . $cache_contents : "";

		//Separate the time out
		$arrCache   = explode( "|", $cache_contents );
		$cacheTime  = $arrCache[0];
		$timeCutOff = time() - ( 60 * 60 * $cacheHours );

		//Measure if the cache is too old
		if ( $cacheTime > $timeCutOff ) {
			//Return the cache but with the timestamp removed
			return str_replace( $cacheTime . "|", "", $cache_contents );
		} else {
			//echo "cacheTime ($cacheTime) <= timeCutOff ($timeCutOff)";
			ethereumadsRemoveCacheFile( $cacheFile, $debug );
			ethereumadsClearOldCache( $cacheFolderName, $cacheHours, $debug ); //Also remove other old cache files
			return false;
		}
	}

}

//Delete a cache file
function ethereumadsRemoveCacheFile( $cacheFile, $debug = false ) {
	if ( ! @unlink( $cacheFile ) ) {
		echo ( $debug ) ? "<li />Error: Could not remove cache file: " . $cacheFile : "";

		return false;
	} else {
		echo ( $debug ) ? "<li />Successfully removed the cache file: " . $cacheFile : "";

		return true;
	}
}

//Loads links from the etherumads web site
function ethereumadsGetLinks( $page, $accountCode, $bannerSize, $slot, $debug = false ) {

	$sizes = explode("x", $bannerSize);

	$width=$sizes[0];
	$height=$sizes[1];

	//Make the URL
	$url = "https://ethereumads.com/htmlsnippet";
	$url = $url . "?address=" . $accountCode;
	$url = $url . "&slot=" . $slot;
	$url = $url . "&width=" . $width;
	$url = $url . "&height=" . $height;
	$url = $url . "&page=" . $page;

	echo ( $debug ) ? "<li />Making call to AB: " . $url : "";

	$response = wp_remote_get( $url );
	$links = wp_remote_retrieve_body( $response );

	return $links;

}

//remove ab_cc etc. from the current page to not interfere with the actual URL
function ethereumadsTrimAbVars( $url ) {

	$url = str_replace( "?ab_cc=1", "", $url );
	$url = str_replace( "&ab_cc=1", "", $url );
	$url = str_replace( "?ab_debug=4bef668c886a91d83ccca8ec69fecc67", "", $url );
	$url = str_replace( "&ab_debug=4bef668c886a91d83ccca8ec69fecc67", "", $url );
	$url = str_replace( "&phpinfo=1", "", $url );

	return $url;

}

//Get page
function ethereumadsGetPageUrl( $debug = false ) {

	$query    = "";
	$protocol = ( isset( $_SERVER['HTTPS'] ) && strtolower( $_SERVER['HTTPS'] ) != "off" ) ? "https://" : "http://";
	$host     = $_SERVER['HTTP_HOST'];
	$page     = false;
	$file     = '';

	if ( !empty($_SERVER["REDIRECT_URL"]) && $_SERVER["REDIRECT_URL"] != "/index.php" ) {
		//Redirect
		if ( isset( $_SERVER['REDIRECT_SCRIPT_URI'] ) ) {
			//Use URI - it is complete
			$page = $_SERVER['REDIRECT_SCRIPT_URI'];
		} else {
			//Use file and query
			$file = $_SERVER["REDIRECT_URL"];
			if ( isset( $_SERVER['REDIRECT_QUERY_STRING'] ) ) {
				$query = "?" . $_SERVER['REDIRECT_QUERY_STRING'];
			}
		}
	} else {
		//No redirect
		if ( isset( $_SERVER['REQUEST_URI'] ) ) {
			//Use URI
			if ( substr( $_SERVER['REQUEST_URI'], 0, 4 ) == "http" ) {
				//Request URI has host in it
				$page = $_SERVER['REQUEST_URI'];
			} else {
				//Request uri lacks host
				$page = $protocol . $host . $_SERVER['REQUEST_URI'];
			}
		} else if ( isset( $_SERVER['SCRIPT_URI'] ) ) {
			//Use URI - it is complete
			$page = $_SERVER['SCRIPT_URI'];
		} else {
			$file = $_SERVER['SCRIPT_NAME'];
			if ( isset( $_SERVER['QUERY_STRING'] ) ) {
				$query = "?" . $_SERVER['QUERY_STRING'];
			}
		}
	}
	if ( ! $page ) {
		$page = $protocol . $host . $file . $query;
	}

	$page = ethereumadsTrimAbVars( $page );

	echo ( $debug ) ? "<li />This page is reported as: " . $page : "";

	return $page;

}
?>